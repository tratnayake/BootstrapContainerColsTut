PixelsDaily
=======================
Name:	12 Flat Apple Product Icons
Type:	PSD
Author: Ali Ashgar


Notes
=======================
A collection of delightful graphics to represent different Apple products, including an iMac, MacBook, Mac Mini, iPhone, iPod, iPad, Apple TV, and a keyboard. Each of these is a great symbolic image for a digital device, and they're made up of completely scalable smart vector objects.



Free Resource Licensing
=======================
All our free resources are licensed under a Creative Commons Attribution license. This license lets you distribute, remix, tweak, and build upon your work, even commercially, as long as you credit PixelsDaily or Creative VIP for the original creation:

http://creativecommons.org/licenses/by/3.0/